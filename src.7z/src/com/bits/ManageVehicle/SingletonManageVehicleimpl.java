package com.bits.ManageVehicle;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.bits.Vehicle.Vehicle;


public class SingletonManageVehicleimpl implements ManageVehicle {
	String vehiclenumber;
	int numberofCars;
	int numberofBikes;
	Date servicedueDate;
	String fuel;
private static ManageVehicle manageVehicle=new SingletonManageVehicleimpl() ;

private SingletonManageVehicleimpl(){};

public static ManageVehicle getInstance(){
	return manageVehicle;
}

public Vehicle getVehicleDetails(String vehicleNum) {
	this.vehiclenumber=vehicleNum;
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
    Date date = new Date();  
	System.out.println("Location of vehicle is Delhi");
	System.out.println("Service is due for"+ vehicleNum+"On"+date.toString() );
	
	
	return null;
}

}


