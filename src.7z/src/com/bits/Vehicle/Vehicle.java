package com.bits.Vehicle;

public interface Vehicle {

	public String vehicleGetDetails(String vehicleNum);
}
