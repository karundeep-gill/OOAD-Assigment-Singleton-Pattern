package com.bits.Vehicle;

public class GetVehicle implements Vehicle {
	
	String[] vehiclenumber = {"DL 5cF1467", "UP 14 CU 4047", "Orange", "Grapes"};

	

	public String vehicleGetDetails(String vehicleNum) {
		for (int temp=0;temp<vehiclenumber.length;temp++){
			if(vehicleNum==vehiclenumber[temp])
			{
				
				return vehicleNum;
				
			}
			
				System.out.println("Vehicle not reg");
				return "aa";
			
		}
		return null;
	}
	

}
