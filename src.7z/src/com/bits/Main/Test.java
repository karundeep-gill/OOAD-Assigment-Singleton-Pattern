package com.bits.Main;

import com.bits.ManageVehicle.ManageVehicle;
import com.bits.ManageVehicle.SingletonManageVehicleimpl;
import com.bits.Vehicle.GetVehicle;

public class Test {

	public static void main(String... s) {
		// CakeFactory cakeFactory = SingletonCakeFactoryimpl.getInstance();
		GetVehicle obj = new GetVehicle();
		String cabNum = obj.vehicleGetDetails("Orange");
		System.out.println(cabNum);
		if (!cabNum.equalsIgnoreCase("aa")) {
			ManageVehicle manageVehicle = SingletonManageVehicleimpl
					.getInstance();
			manageVehicle.getVehicleDetails(cabNum);
		}
	}
}
